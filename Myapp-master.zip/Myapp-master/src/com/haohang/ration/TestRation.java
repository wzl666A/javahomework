package com.haohang.ration;

import org.junit.Test;

public class TestRation {
	@Test
	public void testIsNagetive() {
		System.out.println(Ration.isDaiFenShu(new Ration(6,2)));
	}
}
